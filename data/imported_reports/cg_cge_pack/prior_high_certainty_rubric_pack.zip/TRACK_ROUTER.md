# Track Router — Prevent Category Mistakes

Run this before scoring any campaign.

## Question 1: Who experiences the problem?
Consumer / owner / employee / professional engineer.

## Question 2: Who identifies the failed component?
Record observed evidence.

## Question 3: Who chooses the exact replacement SKU?
This is the decisive variable.

## Question 4: Who pays?
Consumer, business, insurer, landlord, grant body.

## Question 5: Who installs?
Consumer, handyman, licensed professional, onboard engineer.

# Route logic

### D2C_COMPATIBILITY_COMMERCE
Use when:
- consumer/owner selects exact product;
- public checkout exists;
- compatibility can be established remotely;
- professional install, if needed, does not normally control the SKU decision.

Example shape:
old Allaway vacuum -> exact filter/hose/receiver.

### D2C_MIGRATION_BUNDLE
Use when:
- owner can identify current system state;
- deterministic successor kit exists;
- installation may be professional but exact bundle can be selected beforehand.

Must separately prove customer-supplied-part acceptance if installers are involved.

### SERVICE_ORCHESTRATION
Use when:
- user searches for diagnosis/repair;
- professional normally identifies component;
- exact part depends on on-site testing;
- installation/diagnosis is regulated.

The opportunity may still be excellent, but Google Shopping/Shopify is not the primary transaction surface.

### B2B_RESOLUTION
Use when:
- engineer, technician, vessel crew, facilities manager or procurement team is the SKU selector/requisitioner;
- professional installation is normal but not a demand problem.

Primary surface:
photo/nameplate -> exact BOM -> RFQ/PO/API, not consumer storefront.

### BENCHMARK
Use when:
- compatibility problem is excellent;
- incumbent technical resolution is already >=85%;
- useful as evaluation corpus, not storefront.

# Anti-cheat rule

Never use "consumer can buy it online" as proof that the consumer is the chooser.
A public cart button proves only retail availability.
