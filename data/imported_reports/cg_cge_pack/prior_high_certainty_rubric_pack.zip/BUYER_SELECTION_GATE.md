# Buyer / Self-Service Decision Gate

The wrong question is:

> "Can the consumer physically install this?"

The right question is:

> **"Who normally determines the exact SKU before money changes hands?"**

There are four cases.

## Case A — owner chooses and installs
Strong D2C PASS.

## Case B — owner chooses exact SKU, professional installs
Potential D2C PASS if:
- exact compatibility can be resolved remotely;
- law does not prohibit consumer purchase;
- installers commonly accept customer-supplied product or supplier can bundle installation;
- warranty implications are documented.

## Case C — professional diagnoses and chooses
D2C FAIL / SERVICE route.

## Case D — professional employee/engineer chooses for a business
B2B RESOLUTION route.

# Evidence tests

PASS D2C if at least one strong pathway exists:

1. OEM explicitly says user replacement is allowed; OR
2. sample n>=30 with self/owner SKU-selection lower95 >=35%; OR
3. >=20 verified buyer reviews/Q&A across >=2 sellers with >=10 explicit owner-selection cases and no conflicting professional requirement.

FAIL D2C if:
- OEM requires qualified diagnosis/installation and exact part depends on that diagnosis; OR
- n>=30 and upper95 of owner-selection share <25%.

Everything else UNKNOWN.

# Why this exists

A replacement component can have:
- huge installed base;
- perfect fitment graph;
- live public stock;
- terrible supplier content;

and still be a bad consumer campaign if users search "repair my system" and the technician chooses the part.
