# Agent Retrieval / Niche Ownership Test

Structured feeds increase machine readability, but do not guarantee rank.

## Phase 0 — eligibility
Confirm current platform rules and country support.

## Phase 1 — incumbent baseline

Create 30-50 fixed prompts from real intent:
1. exact MPN;
2. asset model + failed component;
3. "what fits X";
4. "does X fit Y";
5. supersession;
6. explicit exclusion;
7. unknown/photo identity;
8. local stock/ETA;
9. successor bundle;
10. cheapest viable correct merchant.

For each prompt record:
- correct answer exists?
- merchant named?
- merchant URL/domain?
- compatibility supported?
- exclusion supported?
- stock/price current?
- best merchant.

Compute:
- `incumbent_full_resolution_rate`
- `merchant_concentration`
- `missing_fact_rate`

## Phase 2 — offline challenger

Run same prompts against our canonical graph.
Need >=90% lower-bound accuracy before store launch.

## Phase 3 — post-launch share-of-answer

Use a fixed test harness:
- same location;
- same prompts;
- clean/new sessions where possible;
- 3 repetitions per prompt;
- ChatGPT shopping + Google AI/Shopping where accessible.

Report:
`our_merchant_appearance_rate`
with Wilson interval.

Do not promise "#1 result".
Platforms state inclusion does not guarantee appearance/rank.

## Ownership target

We call a niche "owned" only when:
- offline resolution >=95%;
- wrong-part rate <3%;
- our merchant appears materially more often over time;
- customers actually transact;
- competitor response has not erased the gap.
