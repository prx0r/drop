# Campaign Submission Checklist

A submission is invalid unless it contains all of:

- [ ] exact atom, not category
- [ ] buyer-role routing
- [ ] surviving-base / annual-event denominator
- [ ] lifecycle trigger evidence
- [ ] >=25 positive compatibility edges
- [ ] >=5 exclusion/supersession edges
- [ ] >=30 buyer-intent observations
- [ ] best-specialist benchmark (>=30 questions)
- [ ] live local supplier stock evidence
- [ ] actual reseller path or explicit UNKNOWN
- [ ] actual supplier costs or explicit nulls
- [ ] addressable annual D2C event calculation
- [ ] required market share calculation
- [ ] operational/safety classification
- [ ] current Google/Shopify/OpenAI eligibility evidence
- [ ] counterevidence search log
- [ ] highest-EVI unresolved action
- [ ] zero ad spend while fatal gates remain UNKNOWN

Gold Campaign condition:
**all required hard gates PASS.**
