# Agent Prompt — Generate a Campaign From Scratch

Do not begin by writing a campaign.

Begin by finding a narrow atom:
`country × OEM × installed asset × generation × component × trigger`.

Then:

1. Route buyer type (D2C / service / B2B / benchmark).
2. Quantify surviving installed base or annual event floor.
3. Prove lifecycle trigger.
4. Extract >=25 compatibility edges and >=5 exclusion/supersession edges.
5. Sample >=30 real buyer-intent events to estimate who chooses the SKU.
6. Find the best technical incumbent and benchmark 30 questions.
7. Verify local transactional stock.
8. Contact/verify reseller path; until then G7=UNKNOWN.
9. Obtain real costs; until then economics=null.
10. Verify current Merchant Center / Shopify / ChatGPT eligibility from first-party docs.
11. Compute deterministic gates.
12. Search aggressively for reasons to kill the idea.

If any hard gate is UNKNOWN, output a `CANDIDATE_EVIDENCE_PACKET`, not a Gold Campaign.
If a professional normally chooses the part, reroute rather than forcing D2C commerce.
