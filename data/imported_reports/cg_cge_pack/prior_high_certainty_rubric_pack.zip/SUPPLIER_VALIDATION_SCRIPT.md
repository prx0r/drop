# Supplier Validation Script

No campaign passes G7 by web inference.

Ask supplier:

1. Can you open a reseller/dealer account for an online retailer?
2. Do you allow public D2C sale of these exact SKUs?
3. Net price / discount schedule?
4. MOQ / annual minimum?
5. Current stock feed: API, EDI, CSV, XML, portal, email?
6. Stock update frequency?
7. Can you blind/direct ship?
8. Dispatch cut-off and carrier?
9. Can neutral packaging be used?
10. Who handles consumer returns?
11. Who handles defective/warranty claims?
12. Restocking fee?
13. Territory restrictions?
14. Brand/OEM listing restrictions?
15. May we use OEM product images/manuals?
16. Can we expose MPN/GTIN publicly?
17. Any products restricted to licensed installers?
18. Can we send structured orders/RFQs automatically?
19. Can we receive order-status/tracking electronically?
20. Who is our technical escalation contact?

Store answers as evidence, never narrative prose.
