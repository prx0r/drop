# Demand Validation Protocol

The denominator is not "installed products".
It is **eligible annual purchase events**.

## Formula

```text
surviving_units_low
× annual_trigger_rate_low
× buyer_selection_share_low
× online_purchase_share_low
= annual_addressable_events_low
```

Each term must have evidence or remain UNKNOWN.

## What counts as validated demand?

### Strong
- actual orders;
- distributor sell-through;
- verified purchase datasets;
- service replacement counts;
- current search/merchant impression data tied to exact component intent.

### Medium
- >=50 recent verified replacement purchases/reviews;
- exact SKU/model search volume;
- recurring stocked listings across >=2 merchants;
- OEM replacement schedule × surviving base.

### Weak
- total category TAM;
- "millions of homes";
- generic Google results;
- forum complaints without buying intent;
- "right to repair is growing".

## Intent taxonomy

Sample exact-intent web evidence and label each event:

- `BUY_EXACT_PART`
- `WHICH_PART_FITS`
- `DIY_REPLACE`
- `BUY_PART_HIRE_INSTALLER`
- `NEED_REPAIRER`
- `NEED_DIAGNOSIS`
- `GENERAL_INFO`

D2C thesis uses only first four as buyer-side addressable intent.

## Required sample

Before D2C campaign:
- n >= 30 exact-intent events from at least 3 source domains/types;
- record query/date/source;
- report Wilson 95% interval for D2C-selection share.

Do not cherry-pick only DIY threads.
