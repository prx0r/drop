# Current Source Notes — 7 Sep 2026

These are platform/market rules the rubric relies on.

## Google Merchant Center

Conversational attributes are optional and intended to help AI systems understand product nuances:
https://support.google.com/merchants/answer/17085370?hl=en

`related_product` is intended for conversational experiences, works in all countries, supports up to 30 relationships, and points to other products in the merchant's inventory:
https://support.google.com/merchants/answer/17085213?hl=en

`document_link` accepts authoritative PDFs and is primarily intended for conversational AI:
https://support.google.com/merchants/answer/17084656?hl=en

`question_and_answer` is intended for conversational AI and can be used in all countries:
https://support.google.com/merchants/answer/17085211?hl=en

MPN guidance:
https://support.google.com/merchants/answer/6324482?hl=en

Product data / free listing requirements:
https://support.google.com/merchants/answer/7052112?hl=en
https://support.google.com/merchants/answer/13889434?hl=en-GB

## Shopify / ChatGPT

Shopify Catalog structures title, description, options, images, price and availability for AI agents, but inclusion does not guarantee appearance or rank:
https://help.shopify.com/en/manual/shopify-catalog
https://help.shopify.com/en/manual/online-sales-channels/agentic-storefronts/products

Shopify agentic storefronts are D2C-only; B2B-only products are excluded where detected:
https://help.shopify.com/en/manual/online-sales-channels/agentic-storefronts/products

Direct Shopify "Selling on ChatGPT" currently requires selling to U.S. customers:
https://help.shopify.com/en/manual/online-sales-channels/agentic-storefronts/chatgpt

OpenAI says Shopify Catalog product data is integrated into ChatGPT and product/merchant selection considers relevance and merchant/product metadata including availability, price and quality:
https://openai.com/index/powering-product-discovery-in-chatgpt/
https://help.openai.com/en/articles/11128490-shopping-with-chatgpt-search

## UFH example

Uponor Finland says 230V room thermostat replacement requires a professional electrician; for 24V, electrician qualification is not required but professional installation/programming is recommended. It also advises contacting its service network for fault situations:
https://www.uponor.com/fi-fi/lattialammityksen-saatojarjestelmien-tukisivusto

Uponor Wirsbo support provides exact successor thermostat information and migration guidance:
https://www.uponor.com/fi-fi/lattialammityksen-saatojarjestelmien-tukisivusto/wirsbo

LVI.fi publicly lists retrofit actuators 1141680 / 1141681 with live observed inventory:
https://lvi.fi/tuote-osasto/taipuisat-muoviputket-ja-osat/muoviputket-pex-ja-osat/toimilaite/
