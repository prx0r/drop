# Rubric B — Statistical Evidence Gate

This version removes subjective 1-10 scoring. Every score is computed from observed numbers.

## Core quantities

### 1. Conservative annual transaction pool

```text
annual_events_low =
    surviving_units_low
  × annual_trigger_rate_low
  × buyer_selection_share_low
  × online_purchase_share_low
```

Use lower confidence/credible bounds where inputs are estimated.

### 2. Gross market contribution pool

```text
annual_contribution_pool_low =
    annual_events_low
  × median_pre_ad_contribution
```

### 3. Required market share

Set campaign target monthly contribution, default `EUR 3,000`.

```text
required_orders_month =
    target_monthly_contribution / median_pre_ad_contribution

required_market_share =
    required_orders_month /
    (annual_events_low / 12)
```

Default PASS: `required_market_share <= 0.05`.

This kills tiny low-margin niches even if they are intellectually interesting.

## Confidence-bound rules

For binary sampled behavior (e.g. self-selection share), use Wilson 95% intervals.

Never use raw `x/n` alone when n < 100.

Required minimum sample:
- buyer-role sample: n >= 30
- incumbent benchmark: n >= 30
- compatibility accuracy: n >= 50
- pilot conversion: n >= 100 qualified sessions unless direct transactions exist

## Measured variables

| Variable | PASS threshold | Notes |
|---|---:|---|
| `surviving_units_low` | >=10,000 | D2C default |
| `annual_events_low` | >=1,000 | after buyer-share adjustment |
| `consumer_selection_share_lower95` | >=0.35 | otherwise service/B2B risk |
| `compatibility_edge_count` | >=25 | initial atom |
| `negative_or_supersession_edges` | >=5 | prevents trivial catalogs |
| `compatibility_test_accuracy_lower95` | >=0.90 | >=50 test cases |
| `supplier_catalog_coverage` | >=0.60 with 2 suppliers OR >=0.80 with 1 | stock <=7 days |
| `incumbent_resolution_rate_upper95` | <0.70 | strong whitespace |
| `offline_our_resolution_rate_lower95` | >=0.90 | pre-launch graph |
| `median_pre_ad_contribution` | >=EUR15 equiv | D2C default |
| `median_contribution_margin` | >=0.20 | D2C default |
| `required_market_share` | <=0.05 | to hit default EUR3k/month contribution |
| `manual_presale_rate_upper95` | <=0.20 | after pilot |
| `return_rate_upper95` | <=0.10 | once >=50 orders |
| `feed_complete_sku_share` | >=0.80 | machine-readable launch set |

## Evidence-adjusted campaign index

For ranking **only after all fatal gates pass**:

```text
EVI_INDEX =
  0.20 * min(1, annual_contribution_pool_low / 250000)
+ 0.20 * (1 - incumbent_resolution_rate)
+ 0.15 * compatibility_test_accuracy
+ 0.15 * supplier_catalog_coverage
+ 0.10 * feed_complete_sku_share
+ 0.10 * min(1, median_pre_ad_contribution / 50)
+ 0.10 * min(1, 0.05 / max(required_market_share, 0.0001))
```

No language model may choose these component scores manually.

## Demand evidence hierarchy

### D4 — actual transactions
Best evidence:
- our sales,
- supplier sales,
- audited order data,
- current marketplace transaction data.

### D3 — observable purchase behavior
- verified purchaser reviews,
- retailer Q&A from purchasers,
- stock turnover with dates,
- repeated out-of-stock/replenishment,
- structured quote/PO datasets.

### D2 — explicit commercial intent
- exact-part/model keyword demand,
- Merchant Center/Search Console impressions,
- paid search query data,
- high-intent forum posts asking where to buy exact replacement.

### D1 — broad interest
- category search,
- generic forum discussion,
- installed-base press release.

A campaign requires D3/D4 or strong D2 plus a mathematically sufficient installed-base event model.

## Bayesian option

When historical campaigns accumulate, replace the fixed priors with empirical Beta priors by niche type:

- consumer self-selection rate;
- compatibility-success rate;
- conversion rate;
- return rate;
- supplier stock reliability.

Do **not** let an LLM invent confidence percentages.

Posterior:
`Beta(alpha_prior + successes, beta_prior + failures)`

Store the prior source and sample size.
