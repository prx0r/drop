# Evidence & Source Policy

## Evidence object

Every fact used in a gate should be stored as:

```json
{
  "evidence_id": "EV-...",
  "claim": "...",
  "metric": "...",
  "value": null,
  "unit": null,
  "country": "FI",
  "asset_generation": "...",
  "as_of": "YYYY-MM-DD",
  "retrieved_at": "ISO-8601",
  "source_tier": "A",
  "source_url": "...",
  "source_title": "...",
  "numerator": null,
  "denominator": null,
  "sample_n": null,
  "method": "...",
  "supports": true,
  "stale_after_days": 365
}
```

## Source tiers

### Tier A
- government/statistical agency;
- OEM/manufacturer;
- official platform documentation;
- official product manual/service bulletin;
- raw transaction/order data;
- contractual supplier quote/terms.

May pass a claim alone when directly on point.

### Tier B
- authorized distributor;
- established retailer with current stock/price;
- trade association;
- service partner;
- reputable industry dataset.

Require two independent sources for decisive claims unless only measuring that source itself.

### Tier C
- Reddit/forums;
- product reviews;
- Q&A;
- social posts;
- search-result observations.

Valid for **behavioral samples**, complaints and discovery.
Never sufficient alone for compatibility or safety.

### Tier D
- AI-generated summaries;
- affiliate/SEO blogs;
- unsourced market-size sites;
- copied catalogs with unclear provenance.

Discovery only. Cannot pass any hard gate.

## Freshness defaults

- stock: 7 days
- supplier price: 30 days
- reseller terms: 90 days
- competition benchmark: 30 days
- AI-platform eligibility/rules: 30 days
- installed base: 3 years unless stock changes slowly
- compatibility: can be old if tied to exact historical generation/manual
- regulation/safety: 90 days or current effective version

## Conflict policy

When sources conflict:
- record both;
- use the more specific primary source;
- otherwise use the conservative value;
- unresolved conflict => UNKNOWN.

No averaging contradictory facts.
