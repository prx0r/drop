# Rubric A — Zero-Bullshit Binary Gate

## Philosophy

Every required gate is exactly one of:

- `PASS`
- `FAIL`
- `UNKNOWN`

There is **no `PROVISIONAL_PASS`** on a hard gate.

Decision is deterministic:

```text
if fatal routing condition -> REROUTE / REJECT
elif any required gate == FAIL -> REJECT
elif any required gate == UNKNOWN -> BLOCKED
else -> ELIGIBLE
```

`UNKNOWN` is not scored as zero and never silently becomes PASS.

## Track router — run before all gates

### R0. Who chooses the exact SKU?

Record four actors separately:

- `problem_noticer`
- `diagnoser`
- `sku_selector`
- `payer`
- `installer`

Allowed outputs:

### D2C_COMPATIBILITY_COMMERCE
PASS routing only if the consumer can rationally choose the exact product **before** hiring a professional, or the product is owner-serviceable.

Accepted evidence:
1. OEM documentation explicitly permits/recommends consumer replacement; OR
2. a structured sample of >=30 exact-component purchase-intent events has `consumer_sku_selection_share_lower95 >= 0.35`; OR
3. >=20 verified purchaser reviews/Q&A across >=2 public retailers contain >=10 explicit self-selection/self-replacement cases, with no legal/professional-install prohibition.

Fatal reroute:
- OEM says diagnosis/replacement requires a qualified professional **and**
- exact SKU choice depends on tests/measurements normally performed by that professional; OR
- sample >=30 has `consumer_sku_selection_share_upper95 < 0.25`.

If fatal: `REROUTE_SERVICE_ORCHESTRATION`.

### B2B_RESOLUTION
Use when engineer/technician/operator is the normal SKU selector and requisitioner.
Do not penalize professional installation; the professional is the user.

### BENCHMARK
Use when the compatibility problem is excellent but an incumbent already owns the decision.

---

# D2C hard gates

## G1 — Addressable surviving installed base

PASS only if either:

A. conservative surviving installed units in target geography >= 10,000; OR
B. conservative annual eligible replacement events >= 1,000.

Requirements:
- geography-specific;
- surviving units, not historic cumulative sales unless attrition is modeled;
- at least one Tier A/B source;
- date/as-of recorded.

Forbidden:
- "large installed base"
- "many old systems"
- using total category count as device-specific installed base.

## G2 — Lifecycle trigger

PASS if at least one target component has a documented recurring trigger:
- failure,
- consumable depletion,
- scheduled maintenance,
- obsolescence,
- successor migration,

AND a conservative annual event rate can be estimated.

Minimum evidence:
- OEM maintenance interval/failure/successor documentation; OR
- >=2 independent transaction/service datasets; OR
- >=30 observed replacement-intent events.

## G3 — Verifiable compatibility graph

PASS only if the initial atom has:
- >=25 independently verifiable positive edges; AND
- >=5 negative/exclusion or supersession edges; AND
- >=80% of edges have Tier A/B evidence; AND
- exact identifiers/revisions are used where available.

Examples:
`FITS`, `DOES_NOT_FIT`, `REPLACED_BY`, `SUPERSEDES`, `REQUIRES_PART`, `REQUIRES_ADAPTER`.

Embeddings, visual similarity or LLM opinion may retrieve candidates but **cannot certify fitment**.

## G4 — Buyer-selection autonomy

This is the anti-heat-pump gate.

PASS if R0 routes to D2C.

FAIL if professional diagnosis normally determines the SKU.

UNKNOWN blocks campaign creation.

## G5 — Local transactional supply

PASS only if:
- >=2 suppliers cover >=60% of the proposed initial SKU set with public/current stock; OR
- one supplier covers >=80%;

AND:
- stock observation is <=7 days old;
- exact supplier SKU/MPN is captured;
- target-country delivery is verified.

Public stock proves supply, **not reseller rights**.

## G6 — Decision-ownership gap

Construct 30 canonical buyer questions across:
- exact model -> part,
- unknown/photo identity,
- supersession,
- negative compatibility,
- bundle/adapter,
- local stock/ETA.

Benchmark the best incumbent.

PASS if:
- no single incumbent gives a fully executable correct answer on >=70% of questions; AND
- our offline graph can answer >=90% correctly; AND
- there is at least one missing decision dimension among `identity`, `fit`, `exclusion`, `supersession`, `stock`, `transaction`.

FAIL if best incumbent >=85% and no material missing dimension exists.

70-85% => UNKNOWN until narrower atom is tested.

## G7 — Reseller/transaction path

PASS only after a real path is verified:

One of:
- supplier confirms reseller account + net pricing;
- supplier confirms affiliate/referral commission;
- supplier confirms direct/blind shipping;
- OEM/authorized source permits us to transact;
- for marketplace model, supplier accepts structured RFQ/order handoff.

Must record:
- named supplier,
- contact date,
- terms,
- MOQ,
- shipping,
- warranty,
- returns/RMA,
- stock feed method.

A public retail listing does not pass this gate.

## G8 — Economics

PASS only with real supplier costs for >=10 representative SKUs or >=30% of launch catalog, whichever is larger.

For each:
`pre_ad_contribution = sale_price - supplier_cost - outbound_shipping - payment_fee - expected_return_cost - platform_variable_cost`

Default D2C thresholds:
- median pre-ad contribution >= EUR 15 equivalent;
- median contribution margin >= 20%;
- >=70% of sampled SKUs meet both;
- no required-share absurdity (see G9).

No guessed "25-35% margin".

## G9 — Validated demand

PASS requires both:

### Market event floor
`annual_d2c_events_low = surviving_units_low × annual_trigger_rate_low × consumer_selection_share_low`

Default: >=1,000 annual D2C events in target geography.

### Observable demand
At least one:
- exact-intent keyword cluster >=100 searches/month from a reproducible source; OR
- >=50 verified recent purchase/replacement events across >=2 merchants/sources within 24 months; OR
- live test >=100 qualified high-intent visits/impressions with >=3 checkout starts/qualified purchase actions; OR
- transaction dataset directly establishes >=1,000 annual events.

Two weak SEO articles do not count.

## G10 — Operational burden

PASS if:
- >=80% of launch SKU decisions can be resolved asynchronously from identifiers/photos/manual evidence;
- pre-sale human intervention is expected <=20%;
- standard parcel fulfillment covers >=80% of orders;
- returns/RMA responsibilities are known.

FAIL D2C if:
- exact choice normally requires on-site diagnosis/proprietary service tool;
- >50% of cases require installer measurement before SKU selection;
- dangerous disassembly is required just to identify the part.

Can reroute to SERVICE or B2B.

## G11 — Agentic feed eligibility

PASS if >=80% of launch SKUs have:
- title,
- clean image,
- non-zero price,
- current availability,
- brand,
- valid GTIN when assigned or correct MPN/identifier handling,
- >=5 deterministic technical attributes,
- compatibility statement,
- source/evidence link internally.

For Google, plan use of:
- `product_detail`
- `question_and_answer`
- `document_link`
- `related_product` only for relationships to products we actually sell.

This is an **eligibility/representation gate**, not an ownership/ranking gate.

## G12 — Retrieval whitespace

Run a fixed baseline suite of >=30 buyer prompts.

PASS if:
- incumbent correct-resolution rate <70%; OR
- incumbent merchant concentration <60% and our graph fills a documented information gap;
- the niche is eligible on at least one immediate channel in the target country.

For Shopify/ChatGPT direct-channel claims, country eligibility must be current and verified.
Do not claim "first result ownership" pre-launch.

---

# BUILD rule

A D2C Gold Campaign can be created only if:
`G1..G12 == PASS`

Exceptions:
- G7 may be UNKNOWN only for a `SUPPLIER_VALIDATION_PACKET`, never a Gold Campaign.
- A benchmark can exist with G6 FAIL, but must be explicitly `BENCHMARK`, not commercial campaign.

# Kill switches

Immediate D2C rejection/reroute:
1. professional normally chooses exact SKU;
2. best incumbent owns >=85% of decision benchmark;
3. no legal transaction path;
4. no conservative annual event pool;
5. net economics below threshold;
6. compatibility cannot be certified;
7. supplier stock cannot be made fresh;
8. product is B2B-only but thesis depends on Shopify agentic storefronts.
