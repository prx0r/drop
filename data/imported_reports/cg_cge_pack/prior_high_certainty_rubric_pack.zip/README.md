# High-Certainty Campaign Rubric Pack

Purpose: prevent attractive-but-non-transactional niches from becoming "Gold Campaigns".

The core distinction is:

> **Installed base is not demand. Compatibility pain is not demand. Public stock is not reseller access. AI-feed eligibility is not AI-result ownership.**

A campaign may exist in four states:

- `CANDIDATE`: an atom worth investigating.
- `BLOCKED`: no fatal contradiction yet, but one or more required gates are UNKNOWN.
- `ELIGIBLE`: all hard gates for its track are PASS.
- `REJECTED` / `REROUTED`: fatal gate failed or the opportunity belongs to another track.

**Gold Campaign creation is only allowed from `ELIGIBLE`.**
A WATCH object is an evidence packet, not a campaign.

## Three rubric variants

1. `RUBRIC_A_BINARY_GATE.md` — strict all-pass/no-pass campaign compiler.
2. `RUBRIC_B_STATISTICAL_GATE.md` — numeric market/economic gate using lower confidence bounds.
3. `RUBRIC_C_ADVERSARIAL_GATE.md` — generator/prosecutor/verifier process designed to falsify campaigns.

Recommended deployment:
- Candidate generation: Rubric C.
- Cheap initial screening: Rubric A.
- Capital allocation / paid ads: Rubric B + A.
- Existing campaign peer review: Rubric C followed by A.

## Critical routing rule

Before evaluating a market, determine **who chooses the exact SKU**.

- Consumer chooses + purchases -> `D2C_COMPATIBILITY_COMMERCE`
- Consumer has problem, professional diagnoses/chooses -> `SERVICE_ORCHESTRATION`
- Professional/operator chooses and requisitions -> `B2B_RESOLUTION`
- Existing incumbent already resolves it exceptionally well -> `BENCHMARK`
- No viable transactional path -> `REJECT`

This is the lesson from residential heat-pump / heating-control parts: an installed base can be enormous while the consumer never enters a replacement-part buying journey.

## Current AI-commerce constraints encoded here

- Google Merchant Center conversational attributes can help AI systems understand products, but are optional and do not establish ranking.
- `related_product` only relates to other products in the merchant inventory.
- Shopify Catalog inclusion does not guarantee appearance or rank in an AI answer.
- Shopify agentic storefronts are D2C-only; B2B-only products are excluded where detected.
- Shopify's direct ChatGPT channel currently requires the store to sell to U.S. customers.
- ChatGPT merchant selection considers merchant/product metadata including availability, price and quality, not merely richness of structured data.

See `SOURCES.md`.
