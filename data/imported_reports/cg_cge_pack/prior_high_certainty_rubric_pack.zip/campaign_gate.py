#!/usr/bin/env python3
"""
Minimal deterministic campaign gate.
Usage:
  python campaign_gate.py candidate.json
"""
import json, sys

REQUIRED = [
 "G1_installed_base",
 "G2_lifecycle_trigger",
 "G3_compatibility_graph",
 "G4_buyer_selection_autonomy",
 "G5_local_transactional_supply",
 "G6_decision_ownership_gap",
 "G7_reseller_path",
 "G8_economics",
 "G9_validated_demand",
 "G10_operational_burden",
 "G11_agentic_feed_eligibility",
 "G12_retrieval_whitespace",
]

def verdict(obj):
    track = obj.get("track")
    if track in {"SERVICE_ORCHESTRATION","B2B_RESOLUTION","BENCHMARK"}:
        return {"verdict":"REROUTE","reason":f"track={track}"}

    gates = obj.get("hard_gates", {})
    missing = [g for g in REQUIRED if g not in gates]
    if missing:
        return {"verdict":"BLOCKED","reason":"missing gates","gates":missing}

    invalid = {k:v for k,v in gates.items() if v not in {"PASS","FAIL","UNKNOWN"}}
    if invalid:
        return {"verdict":"INVALID","reason":"invalid gate states","invalid":invalid}

    failed = [g for g in REQUIRED if gates[g] == "FAIL"]
    if failed:
        return {"verdict":"REJECTED","failed":failed}

    unknown = [g for g in REQUIRED if gates[g] == "UNKNOWN"]
    if unknown:
        return {"verdict":"BLOCKED","unknown":unknown}

    return {"verdict":"ELIGIBLE","decision":"BUILD"}

if __name__ == "__main__":
    with open(sys.argv[1], "r", encoding="utf-8") as f:
        obj=json.load(f)
    print(json.dumps(verdict(obj), indent=2))
