# Rubric C — Adversarial Campaign Court

This is designed for autonomous agents generating or peer-reviewing campaigns.

A campaign is not accepted because one agent can write a persuasive memo.

It must survive three roles.

# Role 1 — GENERATOR

The Generator proposes the smallest viable atom:

`country × OEM ecosystem × installed asset × generation × failing/replenished component × revision/supersession`

Generator must submit:
- claim ledger;
- source ledger;
- 25+ compatibility edges;
- target buyer role;
- 30 canonical buyer prompts;
- best known incumbent;
- supplier list;
- economics with UNKNOWN values left null;
- explicit falsifiers.

Generator is forbidden from using:
- "large market"
- "high margin"
- "poor UX"
- "many suppliers"
without a numeric observation.

# Role 2 — PROSECUTOR

The Prosecutor's job is to kill the campaign.

Mandatory searches:
1. Is the buyer actually looking for a repair person?
2. Does a professional normally choose the SKU?
3. Does the OEM already have an excellent resolver?
4. Is there a specialist with model/serial/photo matching?
5. Is the part available only through authorized installers?
6. Does the product require dangerous/licensed work?
7. Are margins imaginary because wholesale access is unknown?
8. Is the "installed base" really the wrong denominator?
9. Are the relevant parts B2B-only?
10. Is the product already well represented in Google/Shopify/ChatGPT?
11. Are wrong-part returns likely to erase margin?
12. Is demand event frequency too low?
13. Is obsolescence actually causing whole-system replacement instead of part purchases?
14. Are manuals available but public resale restricted?
15. Does the incumbent already expose exact exclusions and supersessions?

The Prosecutor must search for counterevidence, not simply critique the Generator's sources.

# Role 3 — VERIFIER

Verifier re-opens every decisive source and checks:
- the source supports the exact claim;
- geography matches;
- date/version matches;
- product/model matches;
- numeric numerator/denominator are recoverable;
- stock and price are fresh;
- source tier is sufficient;
- no quote/paraphrase changes meaning.

A failed source downgrades the claim to UNKNOWN.

# Deterministic verdict

```text
if routing says SERVICE/B2B:
    verdict = REROUTE
elif any fatal gate FAIL:
    verdict = REJECT
elif any required gate UNKNOWN:
    verdict = BLOCKED
elif all gates PASS:
    verdict = ELIGIBLE
```

No majority vote.

# Claim quorum

For decisive non-platform factual claims:

PASS requires either:
- one Tier A source; OR
- two independent Tier B sources.

Tier C can support behavioral evidence only when sampled systematically.

No claim can pass from:
- AI answer,
- SEO affiliate article,
- unsourced market-size blog,
- generated estimate.

# Negative-search requirement

Every campaign must include:
`COUNTEREVIDENCE_SEARCH_LOG`

Minimum:
- 5 queries aimed at finding a better incumbent;
- 3 queries aimed at finding professional-install constraints;
- 3 queries aimed at finding reseller/OEM restrictions;
- 3 queries aimed at finding weak demand/obsolete-whole-system behavior.

A campaign with only confirming searches is invalid.

# Highest-EVI next action

If BLOCKED, choose the unresolved gate with maximum:

```text
kill_power / test_cost
```

Default priority:
1. buyer/selector role;
2. incumbent ownership gap;
3. reseller permission;
4. unit economics;
5. quantified demand;
6. feed completeness.

Reason: if the consumer never selects the part, there is no D2C campaign no matter how good the compatibility graph is.
